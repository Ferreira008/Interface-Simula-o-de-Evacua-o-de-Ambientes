import streamlit as st
from pathlib import Path

st.set_page_config(page_title="Simulação de Evacuação", layout="wide")

# ---- CSS personalizado ----
st.markdown("""
<style>
.top-nav {
    display: flex;
    gap: 48px;
    align-items: center;
    font-size: 22px;
    margin-bottom: 32px;
}
</style>
""", unsafe_allow_html=True)

# ---- Top Menu com page_link ----
st.markdown('<div class="top-nav">', unsafe_allow_html=True)
st.page_link("app.py", label="Menu", icon="🏠")
st.page_link("pages/1_Mapas.py", label="Mapas", icon="🗺️")
st.page_link("pages/2_Parâmetros.py", label="Parâmetros", icon="⚙️")
st.page_link("pages/3_Resultados.py", label="Resultados", icon="📊")
st.page_link("pages/4_Documentação.py", label="Documentação", icon="📖")
st.markdown('</div>', unsafe_allow_html=True)

# ---- Conteúdo da Home ----
col_left, col_right = st.columns([0.58, 0.42])
with col_left:
    st.title("Simulação de Evacuação de Ambientes")
    st.write(
        "Simule evacuações e avalie a eficiência de diferentes quantidades e posições de saídas de emergência. "
        "Uma ferramenta prática para segurança e planejamento. Inicie sua simulação agora!"
    )
with col_right:
    runner_path = Path("assets/runner_exit.png")
    if runner_path.exists():
        st.image(str(runner_path), use_container_width=True)
