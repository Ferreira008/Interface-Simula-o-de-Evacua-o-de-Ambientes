import streamlit as st

st.set_page_config(page_title="Mapas", layout="wide")

st.title("🗺️ Mapas de Evacuação")
st.write("Aqui você poderá carregar e visualizar os mapas para a simulação.")
