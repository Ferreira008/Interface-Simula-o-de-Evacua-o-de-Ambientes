import streamlit as st

st.set_page_config(page_title="Parâmetros", layout="wide")

st.title("⚙️ Configuração de Parâmetros")
st.write("Defina aqui os parâmetros da simulação.")
